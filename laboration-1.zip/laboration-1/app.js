//Laboration 1

    const blogPosts = require('./blogPosts.js');
    var inlagg = blogPosts.blogPosts;

    var startsida = "index.html";
    var skriv = "skriv.html";
    
    const express = require('express');
    const jsDOM = require('jsdom');
    const fs = require('fs');
    const bodyParser = require('body-parser');

    let app = express();

    app.use('/public', express.static(__dirname + '/staic'));

    app.use(express.urlencoded( {extended : true}));

    app.listen(81, function() {
        console.log('Servern är igång!');
    });

    app.get('/', function(request, response){

        console.log('En utskrift från get...');
        
        fs.readFile(__dirname + '/index.html', function(error, data){
            if(error){
                console.log('fel');
            }
            else{
                let htmlCode = data;

                let serverDOM = new jsDOM.JSDOM(htmlCode);

                let section = serverDOM.window.document.querySelector('section');
                
                for(let i = 0; i < inlagg.length; i++) {
                    
                    let div = serverDOM.window.document.createElement('div');
                    section.appendChild(div);

                    let h4 = serverDOM.window.document.createElement('h4');
                    h4.textContent = inlagg[i].nickName;
                    div.appendChild(h4);
                    
                    let h2 = serverDOM.window.document.createElement('h2');
                    h2.textContent = inlagg[i].msgSubject;
                    div.appendChild(h2);

                    let h6 = serverDOM.window.document.createElement('h6');
                    h6.textContent = inlagg[i].timeStamp;
                    div.appendChild(h6);

                    let p = serverDOM.window.document.createElement('p');
                    p.textContent = inlagg[i].msgBody;
                    div.appendChild(p);
                    

                }

                htmlCode = serverDOM.serialize();

                response.send(htmlCode);

            }
        })
    });



        



    app.post('/skriv', function(request,response){

        console.log(request.body.nickname);
        console.log(request.body.subject);
        console.log(request.body.msgBody);

        var nickName = request.body.nickname;
        var subject = request.body.subject;
        var msgBody = request.body.msgbody;

        if(subject.length < 3 ) {
                
            response.redirect("/skriv");

        } else if(msgBody.length < 10) {
                
            response.redirect("/skriv");

        } else if(nickName.length < 3) {
            
            response.redirect("/skriv");

        }
    
        let date = new Date();
        console.log(date);
        
        inlagg.push({
            msgBody : request.body.msgbody,
            subject : request.body.subject,
            nickName : request.body.nickname,
            timeStamp : date
        });
        response.redirect("/");
    });

    app.get('/skriv', function(request, response) {

        response.sendFile(__dirname + "/skriv.html");
    });



